import { useState } from 'react';
import { motion } from 'framer-motion';
import { Calendar, DollarSign, MapPin, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const SearchSection = () => {
  const [date, setDate] = useState<Date>();

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="relative -mt-24 z-10 max-w-5xl mx-auto px-6"
    >
      <div className="bg-white rounded-lg shadow-xl p-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div>
            <Label className="mb-2 block">Destination</Label>
            <div className="relative">
              <MapPin className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <Input
                placeholder="Where to?"
                className="pl-10"
              />
            </div>
          </div>

          <div>
            <Label className="mb-2 block">Dates</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="w-full justify-start text-left font-normal"
                >
                  <Calendar className="mr-2 h-4 w-4" />
                  {date ? date.toDateString() : "Pick a date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <CalendarComponent
                  mode="single"
                  selected={date}
                  onSelect={setDate}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>

          <div>
            <Label className="mb-2 block">Experience Type</Label>
            <Select>
              <SelectTrigger>
                <Sparkles className="mr-2 h-4 w-4" />
                <SelectValue placeholder="Select type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="adventure">Adventure</SelectItem>
                <SelectItem value="culture">Culture</SelectItem>
                <SelectItem value="relaxation">Relaxation</SelectItem>
                <SelectItem value="culinary">Culinary</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="mb-2 block">Budget Range</Label>
            <Select>
              <SelectTrigger>
                <DollarSign className="mr-2 h-4 w-4" />
                <SelectValue placeholder="Select budget" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="luxury">Premium ($10k+)</SelectItem>
                <SelectItem value="high">High ($5k-$10k)</SelectItem>
                <SelectItem value="medium">Medium ($2k-$5k)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="mt-6 text-center">
          <Button
            size="lg"
            className="bg-navy hover:bg-navy/90 text-white"
          >
            Search Experiences
          </Button>
        </div>
      </div>
    </motion.div>
  );
};

export default SearchSection;