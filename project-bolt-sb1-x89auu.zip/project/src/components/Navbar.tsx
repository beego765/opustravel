import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled ? 'nav-blur py-4' : 'bg-transparent py-6'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 md:px-24">
        <div className="flex items-center justify-between">
          <a href="/" className="text-2xl font-playfair text-navy">
            Luxe Travel
          </a>

          <div className="hidden md:flex items-center space-x-8">
            <NavLinks />
            <Button
              variant="default"
              className="bg-gold hover:bg-gold/90 text-white"
            >
              Book Now
            </Button>
          </div>

          <button
            className="md:hidden text-navy"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          className="md:hidden absolute top-full left-0 right-0 bg-white shadow-lg"
        >
          <div className="px-6 py-4 space-y-4">
            <NavLinks mobile />
            <Button
              variant="default"
              className="w-full bg-gold hover:bg-gold/90 text-white"
            >
              Book Now
            </Button>
          </div>
        </motion.div>
      )}
    </motion.nav>
  );
};

const NavLinks = ({ mobile = false }: { mobile?: boolean }) => {
  const links = ['Destinations', 'Experiences', 'About', 'Contact'];
  const baseClasses = 'font-montserrat text-navy hover:text-gold transition-colors duration-200';
  const mobileClasses = 'block py-2';
  const desktopClasses = '';

  return (
    <>
      {links.map((link) => (
        <a
          key={link}
          href={`#${link.toLowerCase()}`}
          className={`${baseClasses} ${mobile ? mobileClasses : desktopClasses}`}
        >
          {link}
        </a>
      ))}
    </>
  );
};

export default Navbar;