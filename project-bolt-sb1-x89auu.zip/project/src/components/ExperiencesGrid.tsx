import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';

const experiences = [
  {
    id: 1,
    title: 'Private Island Retreat',
    location: 'Maldives',
    price: '$15,000',
    image: 'https://images.unsplash.com/photo-1573843981267-be1999ff37cd?auto=format&fit=crop&w=1920',
    description: 'Experience ultimate luxury in your private overwater villa with personal butler service.',
  },
  {
    id: 2,
    title: 'Alpine Adventure',
    location: 'Swiss Alps',
    price: '$12,000',
    image: 'https://images.unsplash.com/photo-1548777123-e216912df7d8?auto=format&fit=crop&w=1920',
    description: 'Helicopter skiing, luxury chalets, and Michelin-starred mountain dining.',
  },
  {
    id: 3,
    title: 'Safari Expedition',
    location: 'Tanzania',
    price: '$18,000',
    image: 'https://images.unsplash.com/photo-1516426122078-c23e76319801?auto=format&fit=crop&w=1920',
    description: 'Private game drives, luxury camping, and hot air balloon safaris.',
  },
  {
    id: 4,
    title: 'Mediterranean Yacht',
    location: 'Greek Islands',
    price: '$25,000',
    image: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&w=1920',
    description: 'Island-hopping on a private yacht with gourmet chef and crew.',
  },
  {
    id: 5,
    title: 'Cultural Immersion',
    location: 'Kyoto, Japan',
    price: '$10,000',
    image: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=1920',
    description: 'Private tea ceremonies, temple stays, and artisan workshops.',
  },
  {
    id: 6,
    title: 'Desert Oasis',
    location: 'Dubai',
    price: '$20,000',
    image: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=1920',
    description: 'Luxury desert camping, private dune experiences, and exclusive resort access.',
  },
];

const ExperiencesGrid = () => {
  const [selectedExperience, setSelectedExperience] = useState(null);

  return (
    <section className="py-24 px-6 md:px-24 bg-gray-50">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-4xl md:text-5xl font-playfair text-navy mb-16 text-center">
          Curated Experiences
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {experiences.map((experience, index) => (
            <Dialog key={experience.id}>
              <DialogTrigger asChild>
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="experience-card cursor-pointer group"
                >
                  <img
                    src={experience.image}
                    alt={experience.title}
                    className="w-full h-[400px] object-cover"
                  />
                  <div className="absolute bottom-0 left-0 right-0 p-6 text-white z-10">
                    <h3 className="text-2xl font-playfair mb-2">
                      {experience.title}
                    </h3>
                    <p className="text-white/90 mb-2">{experience.location}</p>
                    <p className="text-gold font-semibold">{experience.price}</p>
                  </div>
                </motion.div>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[600px]">
                <DialogHeader>
                  <DialogTitle className="text-2xl font-playfair text-navy">
                    {experience.title}
                  </DialogTitle>
                  <DialogDescription>
                    <img
                      src={experience.image}
                      alt={experience.title}
                      className="w-full h-[300px] object-cover rounded-lg mb-4"
                    />
                    <p className="text-lg mb-4">{experience.description}</p>
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-sm text-gray-600">{experience.location}</p>
                        <p className="text-xl font-semibold text-gold">
                          {experience.price}
                        </p>
                      </div>
                      <Button className="bg-gold hover:bg-gold/90 text-white">
                        Book Now
                      </Button>
                    </div>
                  </DialogDescription>
                </DialogHeader>
              </DialogContent>
            </Dialog>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ExperiencesGrid;