import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ChevronDown } from 'lucide-react';

const Hero = () => {
  return (
    <div className="relative h-screen">
      <video
        autoPlay
        muted
        loop
        playsInline
        className="hero-video"
        poster="https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1920"
      >
        <source
          src="https://player.vimeo.com/external/434045526.hd.mp4?s=81a2fba7af32d0ae0c2f5af95d65fb3b1ac6f329&profile_id=175"
          type="video/mp4"
        />
      </video>

      <div className="absolute inset-0 flex items-center justify-center text-center px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
        >
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-playfair text-white mb-6">
            Experience Luxury
            <br />
            Like Never Before
          </h1>
          <p className="text-lg md:text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            Discover handcrafted journeys to the world's most extraordinary destinations
          </p>
          <Button
            size="lg"
            className="bg-gold hover:bg-gold/90 text-white"
          >
            Start Your Journey
          </Button>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5 }}
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
      >
        <ChevronDown
          className="w-8 h-8 text-white animate-bounce cursor-pointer"
          onClick={() => {
            window.scrollTo({
              top: window.innerHeight,
              behavior: 'smooth'
            });
          }}
        />
      </motion.div>
    </div>
  );
};

export default Hero;