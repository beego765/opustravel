import { useEffect, useRef } from 'react';
import Globe from 'globe.gl';
import { motion } from 'framer-motion';

const GlobeSection = () => {
  const globeRef = useRef();

  useEffect(() => {
    const globe = Globe()(globeRef.current)
      .globeImageUrl('//unpkg.com/three-globe/example/img/earth-dark.jpg')
      .bumpImageUrl('//unpkg.com/three-globe/example/img/earth-topology.png')
      .backgroundColor('#0A1F44')
      .width(window.innerWidth)
      .height(600);

    const destinations = [
      { lat: 3.2028, lng: 73.2207, name: 'Maldives' },
      { lat: 46.8182, lng: 8.2275, name: 'Switzerland' },
      { lat: -2.8547, lng: 35.1662, name: 'Tanzania' },
      { lat: 37.9838, lng: 23.7275, name: 'Greece' },
      { lat: 35.0116, lng: 135.7681, name: 'Kyoto' },
      { lat: 25.2048, lng: 55.2708, name: 'Dubai' },
    ];

    globe
      .pointsData(destinations)
      .pointAltitude(0.1)
      .pointColor(() => '#C6A87D')
      .pointRadius(0.5)
      .pointsMerge(true);

    globe.controls().autoRotate = true;
    globe.controls().autoRotateSpeed = 0.5;

    const handleResize = () => {
      globe.width(window.innerWidth);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <section className="py-24 bg-navy text-white">
      <div className="max-w-7xl mx-auto px-6 md:px-24">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-playfair mb-6">
            Global Destinations
          </h2>
          <p className="text-lg text-white/80 max-w-2xl mx-auto">
            Explore our curated collection of luxury destinations across the globe
          </p>
        </motion.div>

        <div ref={globeRef} className="globe-container" />
      </div>
    </section>
  );
};

export default GlobeSection;