import { useEffect } from 'react';
import { motion, useAnimation } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Compass, Globe, MessageSquare, Search } from 'lucide-react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import SearchSection from './components/SearchSection';
import ExperiencesGrid from './components/ExperiencesGrid';
import GlobeSection from './components/GlobeSection';
import TestimonialsSection from './components/TestimonialsSection';
import ChatWidget from './components/ChatWidget';

function App() {
  const controls = useAnimation();
  const [ref, inView] = useInView();

  useEffect(() => {
    if (inView) {
      controls.start('visible');
    }
  }, [controls, inView]);

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <Hero />
      
      <main>
        <SearchSection />
        
        <motion.div
          ref={ref}
          animate={controls}
          initial="hidden"
          variants={{
            visible: { opacity: 1, y: 0 },
            hidden: { opacity: 0, y: 50 }
          }}
          transition={{ duration: 0.5 }}
          className="py-24 px-6 md:px-24"
        >
          <div className="max-w-7xl mx-auto">
            <h2 className="text-4xl md:text-5xl font-playfair text-navy mb-16 text-center">
              Why Choose Us
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
              {[
                {
                  icon: <Search className="w-8 h-8 text-gold" />,
                  title: "Curated Experiences",
                  description: "Hand-picked luxury destinations and experiences"
                },
                {
                  icon: <Globe className="w-8 h-8 text-gold" />,
                  title: "Global Reach",
                  description: "Access to exclusive locations worldwide"
                },
                {
                  icon: <MessageSquare className="w-8 h-8 text-gold" />,
                  title: "24/7 Concierge",
                  description: "Personal assistance whenever you need it"
                },
                {
                  icon: <Compass className="w-8 h-8 text-gold" />,
                  title: "Bespoke Planning",
                  description: "Customized itineraries tailored to you"
                }
              ].map((feature, index) => (
                <motion.div
                  key={index}
                  className="text-center p-8 bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300"
                  whileHover={{ y: -5 }}
                >
                  <div className="mb-6 inline-block p-4 bg-navy rounded-full">
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-playfair text-navy mb-4">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600">
                    {feature.description}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>

        <ExperiencesGrid />
        <GlobeSection />
        <TestimonialsSection />
      </main>

      <ChatWidget />
    </div>
  );
}

export default App;